const express = require("express");
const path = require("path");
require("dotenv").config();
const OpenAI = require("openai");

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("⚠️ OPENAI_API_KEY n'est pas configurée.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const IMDS_CONTEXT = `
Tu es Assistant IMDS, l'assistant numérique de l'Institution Mixte Le Domaine du Savoir (IMDS).
Réponds en français clair, pratique et professionnel.
Contexte connu : école située à Canaan II, route nationale #1, Rue St-Jacques #30.
Téléphones institutionnels : +509 40409680 / +509 41139669.
Niveaux : Kindergarten, fondamentale et secondaire.
Motto : « Avec le domaine du savoir c’est l’éducation pour l’avenir. »
Pour les documents scolaires, privilégie des structures prêtes à copier, avec titres, dates, classes, signatures et espaces à compléter.
Ne fabrique pas de faits inconnus : utilise [À COMPLÉTER] lorsque l'information manque.
`;

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({error:"La clé OPENAI_API_KEY n'est pas configurée sur le serveur."});
    }
    const { prompt, mode } = req.body || {};
    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({error:"La demande est vide."});
    }

    const modeInstruction = {
      assistant: "Réponds directement à la demande.",
      document: "Produis un document final, propre et prêt à copier dans Word.",
      cours: "Prépare une fiche de leçon complète : objectifs, prérequis, matériel, déroulement, activités, évaluation et devoir.",
      examen: "Prépare un examen structuré avec consignes, barème et corrigé séparé si demandé.",
      parent: "Rédige une communication claire, respectueuse et prête à envoyer aux parents."
    }[mode] || "Réponds directement à la demande.";

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: IMDS_CONTEXT + "\n" + modeInstruction,
      input: prompt
    });

    res.json({answer: response.output_text || "Aucune réponse générée."});
  } catch (err) {
    console.error(err);
    res.status(500).json({error:"Erreur lors de la communication avec le service IA."});
  }
});

app.listen(port, () => console.log(`Assistant IMDS disponible sur http://localhost:${port}`));