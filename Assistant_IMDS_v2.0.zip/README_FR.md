# Assistant IMDS v2.0

## Ce que cette version apporte
- Interface mobile adaptée au téléphone Android
- Assistant IA avec demandes libres
- Modes : assistant, document, leçon, examen, parents
- Contexte institutionnel IMDS
- Historique local dans le navigateur
- Copie et impression
- Clé API conservée côté serveur, jamais dans le HTML

## Installation sur un ordinateur ou un serveur Node.js
1. Installer Node.js.
2. Ouvrir un terminal dans ce dossier.
3. Lancer `npm install`.
4. Copier `.env.example` vers `.env`.
5. Mettre la vraie clé dans `OPENAI_API_KEY`.
6. Lancer `npm start`.
7. Ouvrir `http://localhost:3000`.

## Important
Ne publie jamais le fichier `.env` sur GitHub.
Ne mets jamais la clé API directement dans `index.html`.

## Structure
- `server.js` : serveur sécurisé et appel API
- `public/index.html` : application
- `.env.example` : modèle de configuration
- `package.json` : dépendances
